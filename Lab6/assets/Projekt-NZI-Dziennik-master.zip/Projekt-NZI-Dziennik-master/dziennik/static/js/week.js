
var days = document.querySelector(".days")

var spanik = document.createElement("div")
spanik.style.gridColumnStart = 2
spanik.style.gridRowStart = 1
spanik.innerHTML = "chuj dupa"
days.appendChild(spanik)
console.log("hello word")

